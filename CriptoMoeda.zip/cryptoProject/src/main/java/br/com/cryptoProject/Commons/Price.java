package br.com.cryptoProject.Commons;

public class Price {
	
	private String usd;

	public String getUsd() {
		return usd;
	}

	public void setUsd(String usd) {
		this.usd = usd;
	}


}
