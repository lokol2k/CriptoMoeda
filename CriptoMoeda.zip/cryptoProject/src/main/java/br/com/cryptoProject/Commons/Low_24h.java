package br.com.cryptoProject.Commons;

public class Low_24h {

	private Float usd;

	public Float getUsd() {
		return usd;
	}

	public void setUsd(Float usd) {
		this.usd = usd;
	}
}
