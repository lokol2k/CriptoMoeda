package br.com.cryptoProject.Commons;

import java.util.List;


public class WrapperCoins {
	
	
	private List<String> results;

	public List<String> getResults() {
		return results;
	}

	public void setResults(List<String> results) {
		this.results = results;
	}


}
