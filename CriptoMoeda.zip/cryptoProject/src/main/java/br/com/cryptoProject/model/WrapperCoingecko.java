package br.com.cryptoProject.model;

import java.util.List;



public class WrapperCoingecko {
	
	
	private List<CriptoMoedaCoingecko> results;

	public List<CriptoMoedaCoingecko> getResults() {
		return results;
	}

	public void setResults(List<CriptoMoedaCoingecko> results) {
		this.results = results;
	}

}
