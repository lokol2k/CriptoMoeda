package br.com.cryptoProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CryptoProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CryptoProjectApplication.class, args);
	}

}
