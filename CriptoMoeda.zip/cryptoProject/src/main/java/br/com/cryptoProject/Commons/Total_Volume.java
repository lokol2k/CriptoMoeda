package br.com.cryptoProject.Commons;

public class Total_Volume {
	
	private String usd;

	public String getUsd() {
		return usd;
	}

	public void setUsd(String usd) {
		this.usd = usd;
	}

	

}
